package models;

public interface HasId {

    String getName();

}
