package models;

public interface HasId_Channel extends HasId {
    String getChannelName();
}
